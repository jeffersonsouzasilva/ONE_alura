package br.com.forumhub.api.models.status;

public enum Status {
    NAO_RESPONDIDO,
    RESPONDIDO,
    FECHADO
}
