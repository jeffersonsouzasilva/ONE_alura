package br.com.forumhub.api.dto.security;

public record TokenJWTDto(String token) {
}
