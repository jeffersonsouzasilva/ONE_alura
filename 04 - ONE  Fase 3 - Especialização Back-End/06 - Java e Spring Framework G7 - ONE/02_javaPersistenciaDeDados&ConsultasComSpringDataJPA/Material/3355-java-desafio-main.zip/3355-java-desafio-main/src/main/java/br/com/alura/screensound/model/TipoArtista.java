package br.com.alura.screensound.model;

public enum TipoArtista {
    SOLO,
    DUPLA,
    BANDA;
}
