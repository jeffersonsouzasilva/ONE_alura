package br.com.alura.screenmatchfrases;

public record FraseDTO( String titulo,
                        String frase,
                        String personagem,
                        String poster) {
}
