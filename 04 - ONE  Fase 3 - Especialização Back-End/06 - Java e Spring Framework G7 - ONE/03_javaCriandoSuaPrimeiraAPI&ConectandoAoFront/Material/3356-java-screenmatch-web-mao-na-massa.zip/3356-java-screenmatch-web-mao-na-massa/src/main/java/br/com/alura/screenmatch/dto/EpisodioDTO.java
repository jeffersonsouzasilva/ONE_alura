package br.com.alura.screenmatch.dto;

public record EpisodioDTO(Integer temporada, Integer numeroEpisodio, String titulo) {
}
