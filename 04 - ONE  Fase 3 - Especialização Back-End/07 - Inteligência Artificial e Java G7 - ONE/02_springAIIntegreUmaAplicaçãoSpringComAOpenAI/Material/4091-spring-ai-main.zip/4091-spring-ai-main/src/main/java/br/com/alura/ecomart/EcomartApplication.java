package br.com.alura.ecomart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcomartApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcomartApplication.class, args);
	}

}
