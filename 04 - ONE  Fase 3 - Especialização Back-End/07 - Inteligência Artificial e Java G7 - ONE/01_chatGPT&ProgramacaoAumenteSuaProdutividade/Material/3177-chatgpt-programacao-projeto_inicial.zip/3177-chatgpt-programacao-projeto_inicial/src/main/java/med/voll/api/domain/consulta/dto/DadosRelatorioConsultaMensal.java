package med.voll.api.domain.consulta.dto;

public record DadosRelatorioConsultaMensal(String nome, String crm, Long quantidadeConsultasNoMes) {}
