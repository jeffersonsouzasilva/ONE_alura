import com.br.conversor.modulos.controller.Conection;
import com.google.gson.Gson;
import com.br.conversor.modulos.controller.ExtraOptions;
import com.br.conversor.modulos.ui.InterfaceUi;



public class Principal {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("file.encoding", "UTF-8");
        InterfaceUi.inicio();
    }
}
