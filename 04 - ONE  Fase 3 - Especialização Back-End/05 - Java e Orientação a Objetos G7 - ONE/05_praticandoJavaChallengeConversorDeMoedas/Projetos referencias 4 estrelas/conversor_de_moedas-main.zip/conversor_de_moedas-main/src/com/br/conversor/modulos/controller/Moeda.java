package com.br.conversor.modulos.controller;

public record Moeda(double conversion_rate) {

}
