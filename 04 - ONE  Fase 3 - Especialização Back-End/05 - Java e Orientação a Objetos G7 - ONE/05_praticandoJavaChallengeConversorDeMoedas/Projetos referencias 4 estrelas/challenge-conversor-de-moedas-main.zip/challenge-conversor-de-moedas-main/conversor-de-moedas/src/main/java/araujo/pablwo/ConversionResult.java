package araujo.pablwo;

public record ConversionResult(String result, String baseCode, String targetCode, double conversionRate, double conversionResult) {
}
