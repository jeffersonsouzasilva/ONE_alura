package exception;

public class InvalidOptionException extends Exception {

    public InvalidOptionException() {
        super("Invalid Option\n");
    }
}
