package com.fullbuster.coinconversor.main;

import com.fullbuster.coinconversor.ui.Menu;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException, InterruptedException {

        Menu menu = new Menu();
        menu.showMainMenu();

    }
}