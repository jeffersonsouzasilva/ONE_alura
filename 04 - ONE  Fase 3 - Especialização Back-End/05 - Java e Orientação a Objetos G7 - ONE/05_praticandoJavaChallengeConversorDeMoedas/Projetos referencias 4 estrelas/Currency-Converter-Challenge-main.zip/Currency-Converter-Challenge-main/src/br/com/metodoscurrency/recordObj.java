package br.com.metodoscurrency;

public record recordObj(String base_code, String target_code, double conversion_rate, double conversion_result) {
}